
import React, { useMemo, useState, useEffect, useRef, useCallback } from 'react';
import { createRoot } from 'react-dom/client';
import { CypherCard } from './components/CypherCard';
import { TextScramble } from './components/TextScramble';
import { RedSnow } from './components/RedSnow';
import { BootSequence } from './components/BootSequence';
import { IntroSequence } from './components/IntroSequence';
import { CyberCursor } from './components/CyberCursor';
import { HyperlinkGenerator } from './components/HyperlinkGenerator';
import { IpBypasser } from './components/IpBypasser';
import { CookieRefresher } from './components/CookieRefresher';
import { CardData, NavStatus } from './types';
import { soundEngine } from './utils/audio';

// --- Background Effects ---

const BackgroundPulse = () => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0" aria-hidden="true">
      <div className="bg-radial-pulse animate-bg-pulse-slow"></div>
      <div 
        className="bg-radial-pulse animate-bg-pulse-slow opacity-20" 
        style={{ 
          background: 'radial-gradient(circle, rgba(188, 19, 254, 0.15) 0%, transparent 70%)',
          animationDelay: '-6s',
          filter: 'blur(100px)'
        }}
      ></div>
    </div>
  );
};

const DataParticles = () => {
  const particles = useMemo(() => {
    const particleContents = [
      () => '0x' + Math.random().toString(16).slice(2, 6).toUpperCase(),
      (i: number) => `SYS_LOG_${i}`,
      () => `[${Math.floor(Math.random() * 999)}]`,
      () => '::INIT::',
      () => 'NET_ERR',
      () => Math.random().toString(2).slice(2, 10),
      () => 'KERNEL_PANIC',
      () => 'hacked_us',
    ];

    return Array.from({ length: 50 }).map((_, i) => {
      const contentGenerator = particleContents[Math.floor(Math.random() * particleContents.length)];
      return {
        id: i,
        left: `${Math.random() * 100}%`,
        delay: `${Math.random() * 10}s`, 
        duration: `${5 + Math.random() * 8}s`,
        content: contentGenerator(i)
      };
    });
  }, []);

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 overflow-hidden z-0">
      {particles.map(p => (
        <div 
          key={p.id} 
          className="data-particle animate-data-float"
          style={{ 
            left: p.left, 
            animationDelay: p.delay,
            animationDuration: p.duration,
            fontSize: Math.random() > 0.8 ? '12px' : '9px', // Varied size
            opacity: Math.random() * 0.5 + 0.2 // Varied opacity
          }}
        >
          {p.content}
        </div>
      ))}
    </div>
  );
};

// --- Professional HUD ---

const HUDOverlay = () => {
  const [time, setTime] = useState(new Date());
  
  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-40 p-4 md:p-8 flex flex-col justify-between select-none overflow-hidden">
      {/* Top Bar */}
      <div className="flex justify-between items-start">
        {/* Top Left: System Status */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 text-cypher-cyan text-[10px] font-mono tracking-[0.2em] uppercase opacity-80">
             <div className="w-2 h-2 bg-cypher-cyan animate-pulse shadow-[0_0_8px_#00f0ff]"></div>
             COSMOS_OS // V.4.0.2
          </div>
          <div className="flex items-center gap-1">
             <div className="h-[2px] w-8 bg-cypher-cyan"></div>
             <div className="h-[2px] w-2 bg-cypher-cyan/50"></div>
             <div className="h-[2px] w-32 bg-gradient-to-r from-cypher-cyan/30 to-transparent"></div>
          </div>
          <div className="text-[9px] text-gray-500 font-mono pl-1 leading-relaxed mt-1">
             CPU: <span className="text-white">OPTIMAL</span><br/>
             MEM: <span className="text-white">STABLE</span><br/>
             NET: <span className="text-cypher-green">SECURE</span>
          </div>
        </div>

        {/* Top Right: Time & Session */}
        <div className="flex flex-col gap-2 items-end text-right">
           <div className="text-white text-xl font-sans font-bold tracking-widest flex items-center gap-3">
             {time.toLocaleTimeString()}
             <div className="w-1.5 h-1.5 bg-cypher-magenta rounded-full animate-ping"></div>
           </div>
           <div className="flex items-center gap-1 justify-end">
             <div className="h-[2px] w-32 bg-gradient-to-l from-cypher-magenta/30 to-transparent"></div>
             <div className="h-[2px] w-2 bg-cypher-magenta/50"></div>
             <div className="h-[2px] w-8 bg-cypher-magenta"></div>
           </div>
           <div className="text-[9px] text-gray-500 font-mono pr-1 mt-1">
             SESSION_ID: <span className="text-cypher-purple">0xFF91_ALPHA</span>
           </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="flex justify-between items-end">
         {/* Bottom Left */}
         <div className="flex items-end gap-3 opacity-60">
            <div className="w-[2px] h-16 bg-gradient-to-t from-cypher-green to-transparent"></div>
            <div className="text-[9px] text-gray-400 font-mono leading-tight mb-1">
               COORD: ENCRYPTED<br/>
               IP: HIDDEN_PROXY
            </div>
         </div>
         
         {/* Bottom Right */}
         <div className="flex items-end gap-3 opacity-60">
            <div className="text-[9px] text-gray-400 font-mono text-right leading-tight mb-1">
               SEC_LEVEL: MAX<br/>
               THREAT: <span className="text-cypher-green">NONE</span>
            </div>
            <div className="w-[2px] h-16 bg-gradient-to-t from-cypher-magenta to-transparent"></div>
         </div>
      </div>
    </div>
  )
}

// --- Navigation Components ---

interface NavButtonProps {
  label: string;
  subLabel: string;
  status: NavStatus;
  onClick: () => void;
  color: 'cyan' | 'green' | 'purple' | 'red';
}

const NavButton: React.FC<NavButtonProps> = ({ label, subLabel, status, onClick, color }) => {
  const isArmed = status === 'armed';
  const isActive = status === 'active';

  // Determine border and shadow colors
  let activeBorder = 'border-cypher-cyan/50';
  let activeShadow = 'shadow-[0_0_30px_-5px_rgba(0,240,255,0.3)]';
  
  if (color === 'green') {
    activeBorder = 'border-cypher-green/50';
    activeShadow = 'shadow-[0_0_30px_-5px_rgba(10,255,10,0.3)]';
  } else if (color === 'purple') {
    activeBorder = 'border-cypher-purple/50';
    activeShadow = 'shadow-[0_0_30px_-5px_rgba(188,19,254,0.3)]';
  } else if (color === 'red') {
    activeBorder = 'border-cypher-magenta/50';
    activeShadow = 'shadow-[0_0_30px_-5px_rgba(255,0,60,0.3)]';
  }

  if (isArmed) {
    activeBorder = 'border-orange-500';
    activeShadow = 'shadow-[0_0_30px_-5px_rgba(249,115,22,0.4)]';
  }

  return (
    <button
      onClick={onClick}
      className={`
        group relative px-6 py-3 w-full md:w-auto md:min-w-[200px]
        bg-white/5 hover:bg-white/10 
        border ${isActive || isArmed ? activeBorder : 'border-white/10 hover:border-white/30'}
        rounded-xl transition-all duration-300 
        shadow-lg ${isActive || isArmed ? activeShadow : 'hover:shadow-[0_0_20px_-5px_rgba(255,255,255,0.1)]'}
        active:scale-95
        flex items-center justify-center gap-3
        overflow-hidden
      `}
    >
      {/* Moving Shine Effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
      
      {/* State Indicator Dot */}
      <div className={`
        w-2 h-2 rounded-full transition-all duration-300
        ${isArmed ? 'bg-orange-500 animate-ping' : (isActive ? (color === 'green' ? 'bg-cypher-green shadow-[0_0_8px_#0aff0a]' : color === 'purple' ? 'bg-cypher-purple shadow-[0_0_8px_#bc13fe]' : color === 'red' ? 'bg-cypher-magenta shadow-[0_0_8px_#ff003c]' : 'bg-cypher-cyan shadow-[0_0_8px_#00f0ff]') : 'bg-gray-600 group-hover:bg-white')}
      `}></div>

      {/* Main Label */}
      <div className="flex flex-col items-start">
        <span className={`
          font-sans font-semibold tracking-wide text-sm transition-colors duration-300
          ${isArmed ? 'text-orange-400' : (isActive ? 'text-white' : 'text-gray-300 group-hover:text-white')}
        `}>
          {isArmed ? 'CONFIRM' : label}
        </span>
         <span className="text-[9px] text-gray-500 font-mono tracking-wider group-hover:text-gray-400">
           {subLabel}
         </span>
      </div>
    </button>
  );
};

// --- Data & Main App ---

const cards: CardData[] = [
  {
    id: '1',
    title: 'INJURIES',
    highlightLabel: '[ HIGHLIGHT : BEST SITE ]',
    theme: 'purple',
    status: 'SEC : STABLE',
    icon: 'shield',
    href: 'https://www.logged.tg/auth/cosmos',
    features: [
      { label: 'Fast Login' },
      { label: 'No Captcha' },
      { label: 'Auto Age Verification (13+)' },
      { label: 'Frequently Updated' },
      { label: 'Automatic Secure Account Protection' },
    ]
  },
  {
    id: '2',
    title: 'IMMORTAL',
    highlightLabel: '[ MAIN ALTERNATIVE DOMAIN ]',
    theme: 'cyan',
    status: 'SEC : CRITICAL',
    icon: 'zap',
    href: 'https://immortal.rs/?code=MzQ3NDQwMDE4NDI1NDQ1Mjk1Mw==',
    features: [
      { label: 'Main Alternative Domain' },
      { label: 'Cool Design' },
      { label: 'OP Domain' },
      { label: 'IP Bypasser' },
      { label: 'IP Locker' },
    ]
  },
  {
    id: '3',
    title: 'COSMOS BYPASSER',
    highlightLabel: '[ HIGH_SPEED_ACCESS ]',
    theme: 'green',
    status: 'SEC : OPTIMIZED',
    icon: 'activity',
    href: 'https://rblxbypass.com/d/CosmosOfficial1',
    features: [
      { label: 'Built for speed.' },
      { label: '🔓 Auto Age Bypass' },
      { label: '📩 Gmail Removed in 60s' },
      { label: '⚡ Instant Login' },
      { label: '🔒 Fully Unhooked' },
    ]
  },
  {
    id: '4',
    title: 'SHOCKIFY',
    highlightLabel: '[ NEW : DETECTED ]',
    theme: 'red',
    status: 'SEC : ENFORCED',
    icon: 'zap',
    href: 'https://shockify.st/?code=MTY3NDE4NjE0MTc0OTg3MjA2NA==',
    features: [
      { label: 'Many Domains' },
      { label: 'Auto Age' },
      { label: 'Visit Notifier' },
      { label: 'Auto Secure' },
      { label: 'IP Bypass' },
    ]
  },
  {
    id: '5',
    title: 'CREATE DUALHOOK BYPASSER',
    highlightLabel: '[ ADVANCED : CREATION ]',
    theme: 'blue',
    status: 'SEC : BUILDER',
    icon: 'grid',
    href: 'https://rbx-tool.com/CreateBypass/Cosmos',
    features: [
      { label: 'Create Your Own' },
      { label: 'Auto Age Bypass' },
      { label: 'Instant Login Access' },
      { label: 'Modern UI' },
      { label: '99% Success Rate' },
    ]
  }
];

const App = () => {
  const [bootState, setBootState] = useState<'intro' | 'booting' | 'revealing' | 'complete'>('intro');
  const [activeTab, setActiveTab] = useState<'cosmos' | 'bypasser' | 'tools' | null>(null);
  const [activeTool, setActiveTool] = useState<'link-shortener' | 'ip-bypasser' | 'cookie-refresher' | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Create audio element
    const audio = new Audio("https://files.catbox.moe/9546s3.mp3"); // Lavender Town Slowed
    audio.loop = true;
    audio.volume = 0.4;
    audioRef.current = audio;

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const handleTitleHover = () => {
    soundEngine.playHover('cyan');
  };

  const filteredCards = useMemo(() => {
    if (!activeTab || activeTab === 'tools') return [];
    if (activeTab === 'cosmos') {
      return cards.filter(c => ['1', '2', '4'].includes(c.id));
    }
    if (activeTab === 'bypasser') {
      return cards.filter(c => ['3', '5'].includes(c.id));
    }
    return [];
  }, [activeTab]);

  const handleNavClick = (id: 'cosmos' | 'bypasser' | 'tools') => {
    if (activeTab === id) {
      if (id === 'tools') setActiveTool(null);
      return;
    }
    soundEngine.playEngage();
    setActiveTab(id);
    if (id === 'tools') {
      setActiveTool(null);
    }
  };

  const getStatus = (id: 'cosmos' | 'bypasser' | 'tools'): NavStatus => {
    if (activeTab === id) return 'active';
    return 'idle';
  };

  // --- STABLE CALLBACKS TO PREVENT RE-RENDER LOOPS ---

  const handleIntroComplete = useCallback(() => {
    setBootState('booting');
    // Attempt to play audio after interaction
    if (audioRef.current) {
      audioRef.current.play().catch(e => console.log("Audio play failed:", e));
    }
  }, []);

  const handleBootOpen = useCallback(() => {
    setBootState('revealing');
  }, []);

  const handleBootComplete = useCallback(() => {
    setBootState('complete');
  }, []);

  const handleJoinDiscord = () => {
    window.open('https://discord.gg/XuW8h8KQMM', '_blank');
  };

  // Tools Data
  const toolsCards: CardData[] = [
    {
      id: 'tool-1',
      title: 'LINK SHORTENER',
      theme: 'cyan',
      status: 'SEC: ACTIVE',
      icon: 'link',
      href: '#',
      description: 'Generate professional short links with custom aliases, expiration timers, and 256-bit password protection. Access real-time analytics to track visitor geo-location and device signatures.'
    },
    {
      id: 'tool-2',
      title: 'IP BYPASSER',
      theme: 'red',
      status: 'SEC: BETA',
      icon: 'shield',
      href: '#',
      description: 'Advanced proxy solution to circumvent regional blocks and verification hurdles. Routes traffic through high-velocity residential nodes, ensuring your connection remains undetectable and secure.'
    },
    {
      id: 'tool-3',
      title: 'COOKIE REFRESHER',
      theme: 'purple',
      status: 'SEC: ACTIVE',
      icon: 'lock',
      href: '#',
      description: 'Automated session guardian that prevents timeouts by silently refreshing security tokens. Maintains critical active sessions 24/7, ensuring zero data loss without manual intervention.'
    }
  ];

  return (
    <>
      <CyberCursor />
      
      {bootState === 'intro' && (
        <IntroSequence onComplete={handleIntroComplete} />
      )}

      {(bootState === 'booting' || bootState === 'revealing') && (
         <BootSequence 
          step={bootState}
          onOpen={handleBootOpen} 
          onComplete={handleBootComplete} 
        />
      )}

      {(bootState === 'revealing' || bootState === 'complete') && (
        <div className="min-h-screen flex flex-col items-center relative z-10 cursor-none overflow-x-hidden">
          
          {/* Global Visual Layers */}
          <div className="bg-noise" aria-hidden="true"></div>
          <div className="hex-bg" aria-hidden="true"></div>
          <div className="bg-vignette" aria-hidden="true"></div>
          <div className="scanline" aria-hidden="true"></div>
          <div className="scan-bar" aria-hidden="true"></div>
          <div className="retro-grid" aria-hidden="true"></div>
          
          <BackgroundPulse />
          <RedSnow />
          <DataParticles />
          <HUDOverlay />

          {/* --- Main Content Container --- */}
          <main className="w-full max-w-7xl px-4 md:px-8 pt-20 pb-20 flex flex-col items-center relative z-20">
            
            {/* Header */}
            <header className="mb-12 text-center relative flex flex-col items-center">
              <div className="flex items-center justify-center gap-4 mb-4 opacity-70">
                 <div className="h-px w-12 md:w-24 bg-gradient-to-r from-transparent to-cypher-cyan"></div>
                 <div className="text-[10px] text-cypher-cyan font-mono tracking-[0.5em] animate-pulse">SECURE_GATEWAY_V4</div>
                 <div className="h-px w-12 md:w-24 bg-gradient-to-l from-transparent to-cypher-cyan"></div>
              </div>

              <h1 
                className="text-6xl md:text-8xl font-black tracking-tighter text-white font-sans glitch-text cursor-none select-none drop-shadow-[0_0_15px_rgba(0,240,255,0.3)]" 
                data-text="COSMOS"
                onMouseEnter={handleTitleHover}
              >
                <TextScramble text="COSMOS" />
              </h1>
              
              <div className="mt-4 flex flex-col items-center gap-1">
                 <p className="text-sm font-mono text-gray-400 tracking-[0.25em] uppercase">
                   Digital Asset Interface
                 </p>
                 <div className="w-16 h-1 bg-cypher-magenta mt-2 rounded-full shadow-[0_0_10px_#ff003c]"></div>
              </div>

              {/* Discord Button - Clean Text Only */}
              <button 
                onClick={handleJoinDiscord}
                className="
                  group relative mt-8 px-8 py-3 
                  bg-white/5 hover:bg-white/10 
                  border border-white/10 hover:border-cypher-cyan/50
                  rounded-xl transition-all duration-300 
                  shadow-lg hover:shadow-[0_0_30px_-5px_rgba(0,240,255,0.3)]
                  active:scale-95
                  flex items-center gap-3
                  animate-fade-in
                "
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                <span className="text-gray-300 group-hover:text-white font-sans font-semibold tracking-wide text-sm transition-colors duration-300">
                  Join Discord
                </span>
              </button>
            </header>

            {/* Navigation "Cyber Dock" */}
            <div className="relative mb-16 p-4 w-full flex justify-center">
              {/* Connecting lines for Dock effect */}
              <div className="absolute top-1/2 left-0 right-0 h-px bg-white/10 -z-10 hidden md:block"></div>
              
              <nav className="flex flex-col md:flex-row flex-wrap justify-center items-center gap-6 relative z-10 w-full max-w-6xl">
                
                <NavButton 
                  label="Cosmos Site" 
                  subLabel="MAIN_TOOLS"
                  status={getStatus('cosmos')}
                  onClick={() => handleNavClick('cosmos')}
                  color="cyan"
                />

                <NavButton 
                  label="Tools" 
                  subLabel="UTILITIES"
                  status={getStatus('tools')}
                  onClick={() => handleNavClick('tools')}
                  color="red"
                />

                <NavButton 
                  label="Bypasser" 
                  subLabel="BYPASS_TOOLS"
                  status={getStatus('bypasser')}
                  onClick={() => handleNavClick('bypasser')}
                  color="green"
                />
              </nav>
            </div>

            {/* Content Grid */}
            <div className="w-full min-h-[400px] flex justify-center">
               {!activeTab && (
                  <div className="flex flex-col items-center justify-center h-64 border border-dashed border-white/10 rounded-xl bg-black/20 backdrop-blur-sm animate-pulse-slow w-full max-w-3xl">
                     <div className="text-cypher-cyan font-mono text-sm tracking-[0.2em] mb-2">[ AWAITING_SELECTION ]</div>
                     <div className="text-[10px] text-gray-500 font-mono">SELECT NAVIGATION TO ENGAGE</div>
                  </div>
               )}

               {/* Render Grid for Standard Tabs */}
               {activeTab && activeTab !== 'tools' && (
                <div key={activeTab} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8 animate-fade-in-up w-full">
                  {filteredCards.map((card, index) => (
                    <CypherCard key={card.id} data={card} index={index} />
                  ))}
                </div>
               )}

               {/* Render Tools Tab Logic */}
               {activeTab === 'tools' && (
                 <div className="w-full flex flex-col items-center animate-fade-in-up">
                   
                   {!activeTool && (
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8 w-full">
                        <CypherCard 
                          data={toolsCards[0]} 
                          index={0} 
                          onClick={() => setActiveTool('link-shortener')}
                        />
                        <CypherCard 
                          data={toolsCards[1]} 
                          index={1} 
                          onClick={() => setActiveTool('ip-bypasser')}
                        />
                         <CypherCard 
                          data={toolsCards[2]} 
                          index={2} 
                          onClick={() => setActiveTool('cookie-refresher')}
                        />
                     </div>
                   )}

                   {/* Render Active Tool with Back Button */}
                   {activeTool && (
                     <div className="w-full flex flex-col items-center">
                       <button 
                          onClick={() => setActiveTool(null)}
                          className="self-start mb-6 flex items-center gap-2 text-sm font-mono text-gray-400 hover:text-white transition-colors group"
                       >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="group-hover:-translate-x-1 transition-transform">
                            <line x1="19" y1="12" x2="5" y2="12"></line>
                            <polyline points="12 19 5 12 12 5"></polyline>
                          </svg>
                          BACK TO TOOLS
                       </button>

                       {activeTool === 'link-shortener' && <HyperlinkGenerator />}
                       {activeTool === 'ip-bypasser' && <IpBypasser />}
                       {activeTool === 'cookie-refresher' && <CookieRefresher />}
                     </div>
                   )}
                 </div>
               )}
            </div>

          </main>

          {/* Fixed Footer */}
          <footer className="fixed bottom-0 left-0 right-0 h-10 bg-gradient-to-t from-black to-transparent z-50 pointer-events-none flex items-end justify-center pb-2">
            <div className="flex items-center gap-4 text-[9px] font-mono text-gray-600 tracking-widest uppercase opacity-70">
              <span>INJURIES.CORP</span>
              <span className="w-1 h-1 bg-gray-600 rounded-full"></span>
              <span>ALL_SYSTEMS_GO</span>
              <span className="w-1 h-1 bg-gray-600 rounded-full"></span>
              <span>ENCRYPTED_256</span>
            </div>
          </footer>

        </div>
      )}
    </>
  );
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
