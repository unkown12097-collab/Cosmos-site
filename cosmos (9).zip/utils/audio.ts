
import { ThemeColor } from '../types';

/**
 * Procedural Sound Engine for Futuristic UI Feedback
 * Synthesizes sounds in real-time to avoid loading external assets.
 */
class SoundEngine {
  private ctx: AudioContext | null = null;

  private init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  /**
   * Short holographic 'zip' for hover feedback
   */
  playHover(theme: ThemeColor = 'cyan') {
    try {
      this.init();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();
      
      const pitchMap: Record<string, number> = {
        purple: 440,   // A4
        cyan: 880,     // A5
        green: 659,    // E5
        magenta: 784,  // G5
        red: 523,      // C5
        orange: 698,   // F5
        blue: 932,     // Bb5
      };

      const baseFreq = pitchMap[theme] || 880;
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq, now);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 2.5, now + 0.05);
      
      filter.type = 'highpass';
      filter.frequency.setValueAtTime(1000, now);

      gain.gain.setValueAtTime(0.015, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
      
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start();
      osc.stop(now + 0.05);
    } catch (e) {}
  }

  /**
   * Dual-pulse 'scan' sound for interaction feedback
   */
  playClick() {
    try {
      this.init();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc1 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc1.type = 'square';
      osc1.frequency.setValueAtTime(150, now);
      osc1.frequency.exponentialRampToValueAtTime(800, now + 0.1);
      
      gain.gain.setValueAtTime(0.03, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      
      osc1.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc1.start();
      osc1.stop(now + 0.12);
    } catch (e) {}
  }

  /**
   * Warning tone when user clicks once (Armed state)
   */
  playArm() {
    try {
      this.init();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      // Warning tone (Sawtooth)
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, now); // Low A3
      osc.frequency.linearRampToValueAtTime(110, now + 0.2); // Drop pitch

      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start();
      osc.stop(now + 0.2);
    } catch (e) {}
  }

  /**
   * Heavy mechanical sound for final activation
   */
  playEngage() {
    try {
      this.init();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const noise = this.ctx.createBufferSource();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      // 1. Low Bass Thud
      osc.type = 'square';
      osc.frequency.setValueAtTime(50, now);
      osc.frequency.exponentialRampToValueAtTime(10, now + 0.3);
      
      // 2. Filter sweep
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(500, now);
      filter.frequency.exponentialRampToValueAtTime(50, now + 0.3);

      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(now + 0.4);

    } catch (e) {}
  }

  /**
   * Micro-tick for text scrambling
   */
  playTick() {
    try {
      this.init();
      if (!this.ctx || this.ctx.state !== 'running') return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(2000 + Math.random() * 1000, now);
      
      gain.gain.setValueAtTime(0.005, now);
      gain.gain.linearRampToValueAtTime(0, now + 0.005);
      
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start();
      osc.stop(now + 0.005);
    } catch (e) {}
  }
}

export const soundEngine = new SoundEngine();
