
export type ThemeColor = 'purple' | 'red' | 'orange' | 'cyan' | 'magenta' | 'blue' | 'green';

export type IconType = 'shield' | 'message' | 'zap' | 'activity' | 'globe' | 'lock' | 'grid' | 'link';

export type CardLayout = 'list' | 'stats' | 'text' | 'hybrid';

export type NavStatus = 'idle' | 'active' | 'armed';

export interface CardFeature {
  label: string;
}

export interface CardStat {
  label: string;
  value: string;
}

export interface CardData {
  id: string;
  title: string;
  highlightLabel?: string; // New field for "[ HIGHLIGHT: BEST SITE ]"
  theme: ThemeColor;
  status: string;
  icon: IconType;
  layout?: CardLayout; // Optional now, as we default to a standard hybrid layout
  features?: CardFeature[];
  stats?: CardStat[];
  description?: string;
  href: string;
}

export interface ThemeStyles {
  glow: string;
  border: string;
  text: string;
  bg: string;
  bullet: string;
  indicator: string;
}