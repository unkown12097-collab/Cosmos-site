import React from 'react';
import { CardData, ThemeStyles, ThemeColor, IconType } from '../types';
import { StatusBadge } from './StatusBadge';

interface VibeCardProps {
  data: CardData;
  index: number;
}

const themeStyles: Record<ThemeColor, ThemeStyles> = {
  purple: {
    glow: 'shadow-[0_0_20px_-5px_rgba(168,85,247,0.2)] hover:shadow-[0_0_35px_-5px_rgba(168,85,247,0.4)]',
    border: 'border-purple-500/20 hover:border-purple-500/50',
    text: 'text-purple-400',
    bg: 'bg-gradient-to-br from-purple-900/10 via-vibe-panel/80 to-transparent',
    bullet: 'text-purple-500',
    indicator: 'bg-purple-500'
  },
  magenta: {
    glow: 'shadow-[0_0_20px_-5px_rgba(236,72,153,0.2)] hover:shadow-[0_0_35px_-5px_rgba(236,72,153,0.4)]',
    border: 'border-pink-500/20 hover:border-pink-500/50',
    text: 'text-pink-400',
    bg: 'bg-gradient-to-br from-pink-900/10 via-vibe-panel/80 to-transparent',
    bullet: 'text-pink-500',
    indicator: 'bg-pink-500'
  },
  red: {
    glow: 'shadow-[0_0_20px_-5px_rgba(239,68,68,0.2)] hover:shadow-[0_0_35px_-5px_rgba(239,68,68,0.4)]',
    border: 'border-red-500/20 hover:border-red-500/50',
    text: 'text-red-400',
    bg: 'bg-gradient-to-br from-red-900/10 via-vibe-panel/80 to-transparent',
    bullet: 'text-red-500',
    indicator: 'bg-red-500'
  },
  orange: {
    glow: 'shadow-[0_0_20px_-5px_rgba(249,115,22,0.2)] hover:shadow-[0_0_35px_-5px_rgba(249,115,22,0.4)]',
    border: 'border-orange-500/20 hover:border-orange-500/50',
    text: 'text-orange-400',
    bg: 'bg-gradient-to-br from-orange-900/10 via-vibe-panel/80 to-transparent',
    bullet: 'text-orange-500',
    indicator: 'bg-orange-500'
  },
  cyan: {
    glow: 'shadow-[0_0_20px_-5px_rgba(6,182,212,0.2)] hover:shadow-[0_0_35px_-5px_rgba(6,182,212,0.4)]',
    border: 'border-cyan-500/20 hover:border-cyan-500/50',
    text: 'text-cyan-400',
    bg: 'bg-gradient-to-br from-cyan-900/10 via-vibe-panel/80 to-transparent',
    bullet: 'text-cyan-500',
    indicator: 'bg-cyan-500'
  },
  blue: {
    glow: 'shadow-[0_0_20px_-5px_rgba(59,130,246,0.2)] hover:shadow-[0_0_35px_-5px_rgba(59,130,246,0.4)]',
    border: 'border-blue-500/20 hover:border-blue-500/50',
    text: 'text-blue-400',
    bg: 'bg-gradient-to-br from-blue-900/10 via-vibe-panel/80 to-transparent',
    bullet: 'text-blue-500',
    indicator: 'bg-blue-500'
  },
  green: {
    glow: 'shadow-[0_0_20px_-5px_rgba(34,197,94,0.2)] hover:shadow-[0_0_35px_-5px_rgba(34,197,94,0.4)]',
    border: 'border-green-500/20 hover:border-green-500/50',
    text: 'text-green-400',
    bg: 'bg-gradient-to-br from-green-900/10 via-vibe-panel/80 to-transparent',
    bullet: 'text-green-500',
    indicator: 'bg-green-500'
  }
};

const Icons: Record<IconType, React.FC<{ className?: string }>> = {
  shield: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
  ),
  message: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
  ),
  zap: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
  ),
  activity: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
  ),
  globe: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
  ),
  lock: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
  ),
  grid: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
  ),
  link: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
  )
};

const ArrowIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <line x1="5" y1="12" x2="19" y2="12"></line>
    <polyline points="12 5 19 12 12 19"></polyline>
  </svg>
);

export const VibeCard: React.FC<VibeCardProps> = ({ data, index }) => {
  const styles = themeStyles[data.theme];
  const Icon = Icons[data.icon];

  const renderContent = () => {
    switch (data.layout) {
      case 'stats':
        return (
          <div className="flex gap-4 mb-8 mt-2">
            {data.stats?.map((stat, idx) => (
              <div key={idx} className="flex-1 bg-black/20 rounded p-3 border border-white/5 backdrop-blur-sm group-hover:border-white/10 transition-colors">
                <div className={`text-2xl font-bold ${styles.text} mb-1 tracking-tighter`}>{stat.value}</div>
                <div className="text-[10px] text-gray-500 uppercase tracking-widest font-mono">{stat.label}</div>
              </div>
            ))}
          </div>
        );
      case 'text':
        return (
          <div className="mb-8 mt-2 pr-4">
             <p className="text-gray-400 text-sm leading-relaxed font-mono">
               {data.description}
             </p>
          </div>
        );
      case 'list':
      default:
        return (
          <div className="space-y-3 mb-10 mt-2">
            {data.features?.map((feature, idx) => (
              <div key={idx} className="flex items-center gap-3 group-hover:translate-x-1 transition-transform duration-300" style={{ transitionDelay: `${idx * 50}ms` }}>
                <span className={`${styles.bullet} text-xs transform rotate-90`}>▲</span>
                <span className="text-gray-400 font-medium text-sm md:text-base tracking-wide font-mono group-hover:text-gray-200 transition-colors">
                  {feature.label}
                </span>
              </div>
            ))}
          </div>
        );
    }
  };

  return (
    <a 
      href={data.href}
      target="_blank"
      rel="noopener noreferrer"
      className={`
        group relative flex flex-col w-full p-6 
        bg-vibe-panel/40 backdrop-blur-md
        border ${styles.border} 
        rounded-2xl 
        transition-all duration-300 ease-out
        ${styles.glow}
        ${styles.bg}
        hover:-translate-y-1
        overflow-hidden
        animate-fade-in-up
        opacity-0
      `}
      style={{ animationDelay: `${index * 150}ms`, animationFillMode: 'forwards' }}
    >
      {/* Background Pulse Animation */}
      <div className={`absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-700 bg-${data.theme}-500 mix-blend-overlay`}></div>

      {/* Holographic Shimmer Effect */}
      <div className="absolute inset-0 z-0 hidden group-hover:block pointer-events-none rounded-2xl overflow-hidden">
        <div className="absolute top-0 bottom-0 left-0 right-0 w-[200%] bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full animate-shimmer"></div>
      </div>

      {/* Header Area */}
      <div className="relative z-10 flex justify-between items-start mb-4">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg bg-white/5 border border-white/5 ${styles.text}`}>
            <Icon className="w-6 h-6" />
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-white uppercase font-sans">
            {data.title}
          </h2>
        </div>
        <StatusBadge status={data.status} theme={data.theme} />
      </div>

      {/* Dynamic Content Area */}
      <div className="relative z-10 flex-grow">
        {renderContent()}
      </div>

      {/* Action Footer */}
      <div className="relative z-10 flex items-center justify-between border-t border-white/5 pt-4 mt-auto">
        <span className={`text-[10px] font-mono font-bold tracking-[0.2em] transition-all duration-300 ${styles.text} opacity-70 group-hover:opacity-100 group-hover:tracking-[0.25em]`}>
          ACCESS_GRANTED
        </span>
        
        <div className={`
          flex items-center justify-center w-10 h-10 rounded-full 
          border border-white/10 bg-black/20 
          text-gray-400
          group-hover:bg-${data.theme}-500 group-hover:border-${data.theme}-400 group-hover:text-white 
          group-hover:scale-110 group-hover:shadow-[0_0_15px_rgba(255,255,255,0.3)]
          transition-all duration-300
        `}>
          <div className="-rotate-45 group-hover:rotate-0 transition-transform duration-300">
            <ArrowIcon />
          </div>
        </div>
      </div>

      {/* Decorative corner accents */}
      <div className={`absolute bottom-0 left-0 w-16 h-16 bg-gradient-to-tr from-${data.theme}-500/5 to-transparent rounded-bl-2xl pointer-events-none`}></div>
    </a>
  );
};