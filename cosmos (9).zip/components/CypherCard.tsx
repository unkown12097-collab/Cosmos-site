
import React, { useState, useRef } from 'react';
import { CardData, ThemeStyles, ThemeColor, IconType } from '../types';
import { StatusBadge } from './StatusBadge';
import { soundEngine } from '../utils/audio';

interface CypherCardProps {
  data: CardData;
  index: number;
  onClick?: () => void;
}

// Enhanced Palette with Spotlight colors and Chip styles
interface EnhancedThemeStyles extends ThemeStyles {
  spotlight: string;
  chipBorder: string;
}

const themeStyles: Record<ThemeColor, EnhancedThemeStyles> = {
  blue: {
    glow: 'shadow-[0_0_30px_-5px_rgba(0,240,255,0.3)] hover:shadow-[0_0_50px_-10px_rgba(0,240,255,0.5)]',
    border: 'border-cypher-cyan/30 hover:border-cypher-cyan/60',
    text: 'text-cypher-cyan',
    bg: 'bg-black/40',
    bullet: 'text-cypher-cyan',
    indicator: 'bg-cypher-cyan',
    spotlight: 'rgba(0, 240, 255, 0.15)',
    chipBorder: 'group-hover:border-cypher-cyan/30'
  },
  purple: {
    glow: 'shadow-[0_0_30px_-5px_rgba(188,19,254,0.3)] hover:shadow-[0_0_50px_-10px_rgba(188,19,254,0.5)]',
    border: 'border-cypher-purple/30 hover:border-cypher-purple/60',
    text: 'text-cypher-purple',
    bg: 'bg-black/40',
    bullet: 'text-cypher-purple',
    indicator: 'bg-cypher-purple',
    spotlight: 'rgba(188, 19, 254, 0.15)',
    chipBorder: 'group-hover:border-cypher-purple/30'
  },
  green: {
    glow: 'shadow-[0_0_30px_-5px_rgba(10,255,10,0.3)] hover:shadow-[0_0_50px_-10px_rgba(10,255,10,0.5)]',
    border: 'border-cypher-green/30 hover:border-cypher-green/60',
    text: 'text-cypher-green',
    bg: 'bg-black/40',
    bullet: 'text-cypher-green',
    indicator: 'bg-cypher-green',
    spotlight: 'rgba(10, 255, 10, 0.15)',
    chipBorder: 'group-hover:border-cypher-green/30'
  },
  cyan: {
    glow: 'shadow-[0_0_30px_-5px_rgba(0,240,255,0.3)] hover:shadow-[0_0_50px_-10px_rgba(0,240,255,0.5)]',
    border: 'border-cypher-cyan/30 hover:border-cypher-cyan/60',
    text: 'text-cypher-cyan',
    bg: 'bg-black/40',
    bullet: 'text-cypher-cyan',
    indicator: 'bg-cypher-cyan',
    spotlight: 'rgba(0, 240, 255, 0.15)',
    chipBorder: 'group-hover:border-cypher-cyan/30'
  },
  magenta: {
    glow: 'shadow-[0_0_30px_-5px_rgba(255,0,60,0.3)] hover:shadow-[0_0_50px_-10px_rgba(255,0,60,0.5)]',
    border: 'border-cypher-magenta/30 hover:border-cypher-magenta/60',
    text: 'text-cypher-magenta',
    bg: 'bg-black/40',
    bullet: 'text-cypher-magenta',
    indicator: 'bg-cypher-magenta',
    spotlight: 'rgba(255, 0, 60, 0.15)',
    chipBorder: 'group-hover:border-cypher-magenta/30'
  },
  red: {
    glow: 'shadow-[0_0_30px_-5px_rgba(255,0,60,0.3)] hover:shadow-[0_0_50px_-10px_rgba(255,0,60,0.5)]',
    border: 'border-cypher-magenta/30 hover:border-cypher-magenta/60',
    text: 'text-cypher-magenta',
    bg: 'bg-black/40',
    bullet: 'text-cypher-magenta',
    indicator: 'bg-cypher-magenta',
    spotlight: 'rgba(255, 0, 60, 0.15)',
    chipBorder: 'group-hover:border-cypher-magenta/30'
  },
  orange: {
    glow: 'shadow-[0_0_30px_-5px_rgba(255,165,0,0.3)] hover:shadow-[0_0_50px_-10px_rgba(255,165,0,0.5)]',
    border: 'border-orange-500/30 hover:border-orange-500/60',
    text: 'text-orange-500',
    bg: 'bg-black/40',
    bullet: 'text-orange-500',
    indicator: 'bg-orange-500',
    spotlight: 'rgba(255, 165, 0, 0.15)',
    chipBorder: 'group-hover:border-orange-500/30'
  }
};

const Icons: Record<IconType, React.FC<{ className?: string }>> = {
  shield: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><circle cx="12" cy="11" r="3"/></svg>
  ),
  message: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><line x1="9" y1="10" x2="15" y2="10"/></svg>
  ),
  zap: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
  ),
  activity: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/><circle cx="12" cy="12" r="1"/></svg>
  ),
  globe: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
  ),
  lock: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="0" ry="0"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
  ),
  grid: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
  ),
  link: ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
  )
};

export const CypherCard: React.FC<CypherCardProps> = ({ data, index, onClick }) => {
  const styles = themeStyles[data.theme] || themeStyles.blue;
  const Icon = Icons[data.icon];
  
  // Refs and State
  const cardRef = useRef<HTMLAnchorElement | HTMLButtonElement>(null);
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [ripples, setRipples] = useState<{x: number, y: number, id: number}[]>([]);
  const [isClicked, setIsClicked] = useState(false);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isHovered || !cardRef.current) return;
    
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Set spotlight variables
    cardRef.current.style.setProperty('--mouse-x', `${x}px`);
    cardRef.current.style.setProperty('--mouse-y', `${y}px`);

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    // Smooth tilt effect
    const rotateX = ((y - centerY) / centerY) * -4; 
    const rotateY = ((x - centerX) / centerX) * 4;

    setRotation({ x: rotateX, y: rotateY });
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
    soundEngine.playHover(data.theme);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotation({ x: 0, y: 0 });
  };

  const handleClick = (e: React.MouseEvent) => {
    soundEngine.playClick();
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = Date.now();
    
    setRipples(prev => [...prev, { x, y, id }]);
    setIsClicked(true);
    
    setTimeout(() => {
      setRipples(prev => prev.filter(r => r.id !== id));
      setIsClicked(false);
    }, 600);
  };

  const Component = onClick ? 'button' : 'a';

  return (
    <div className="w-full h-full perspective-card relative z-30 group" style={{ perspective: '1200px' }}>
      <Component
        ref={cardRef as any}
        href={onClick ? undefined : data.href}
        onClick={(e: React.MouseEvent) => {
          if (onClick) {
            e.preventDefault();
            handleClick(e);
            onClick();
          } else {
            handleClick(e);
          }
        }}
        target={onClick ? undefined : "_blank"}
        rel={onClick ? undefined : "noopener noreferrer"}
        onMouseMove={handleMouseMove}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className={`
          relative flex flex-col w-full h-full p-8 text-left
          rounded-3xl
          border ${styles.border}
          transition-all duration-500 cubic-bezier(0.2, 0.8, 0.2, 1)
          ${styles.bg} backdrop-blur-xl
          ${isHovered ? 'z-50' : 'z-30'}
          animate-holographic
          opacity-0
          cursor-none
          overflow-hidden
        `}
        style={{ 
          animationDelay: `${index * 150}ms`, 
          animationFillMode: 'forwards',
          transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) scale3d(${isHovered ? 1.02 : 1}, ${isHovered ? 1.02 : 1}, 1)`,
          boxShadow: isHovered ? `0 20px 60px -15px ${data.theme === 'purple' ? 'rgba(188,19,254,0.3)' : data.theme === 'green' ? 'rgba(10,255,10,0.3)' : 'rgba(0,240,255,0.3)'}` : 'none'
        }}
      >
        {/* === MOUSE SPOTLIGHT LAYER === */}
        <div 
          className="absolute inset-0 z-0 transition-opacity duration-500 opacity-0 group-hover:opacity-100 pointer-events-none"
          style={{
            background: `radial-gradient(800px circle at var(--mouse-x, 50%) var(--mouse-y, 50%), ${styles.spotlight}, transparent 40%)`
          }}
        />

        {/* === DOT PATTERN TEXTURE === */}
        <div 
          className="absolute inset-0 z-0 opacity-[0.07] pointer-events-none" 
          style={{ 
            backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', 
            backgroundSize: '24px 24px' 
          }}
        ></div>

        {/* === RIPPLE EFFECT LAYER === */}
        {ripples.map(ripple => (
          <span
            key={ripple.id}
            className={`absolute rounded-full pointer-events-none opacity-50 ${styles.indicator} animate-ripple-expand`}
            style={{
              left: ripple.x,
              top: ripple.y,
              width: '20px',
              height: '20px',
              zIndex: 100,
            }}
          />
        ))}

        {/* === ANIMATION & DECORATION LAYER === */}
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-white/5 to-transparent"></div>

        {/* Header Area */}
        <div className="relative z-10 flex justify-between items-start mb-6" style={{ transform: 'translateZ(20px)' }}>
          <div className="flex items-center gap-4">
            <div className={`
              p-3 rounded-2xl bg-white/5 border border-white/10 
              ${styles.text} 
              transition-all duration-300 
              group-hover:scale-105 group-hover:bg-white/10 group-hover:shadow-[0_0_15px_-3px_currentColor]
              group-hover:border-white/20
            `}>
              <Icon className="w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <h2 className="text-xl font-bold tracking-tight text-white font-sans group-hover:text-shadow-sm transition-all">
                {data.title}
              </h2>
               {data.highlightLabel && (
                  <span className={`text-[10px] font-mono font-bold tracking-widest ${styles.text} uppercase opacity-80 mt-1`}>
                    {data.highlightLabel}
                  </span>
               )}
            </div>
          </div>
          <StatusBadge status={data.status} theme={data.theme} />
        </div>

        {/* Content Area - Tech Spec Chips or Description */}
        <div className="relative z-10 flex-grow" style={{ transform: 'translateZ(10px)' }}>
          {data.features && data.features.length > 0 ? (
            <div className="grid grid-cols-1 gap-2 mt-2">
              {data.features.map((feature, idx) => (
                <div 
                  key={idx} 
                  className={`
                    flex items-center gap-3 px-4 py-2.5 rounded-xl
                    bg-white/5 border border-white/5
                    transition-all duration-300
                    ${styles.chipBorder}
                    group-hover:bg-white/[0.07]
                    hover:!translate-x-1
                  `}
                  style={{ transitionDelay: `${idx * 40}ms` }}
                >
                  <div className={`w-1.5 h-1.5 rounded-full ${styles.indicator} shadow-[0_0_6px_currentColor] opacity-80 group-hover:opacity-100`}></div>
                  <span className="text-gray-300 font-minimal text-xs md:text-sm tracking-wide group-hover:text-white transition-colors">
                    {feature.label}
                  </span>
                </div>
              ))}
            </div>
          ) : data.description ? (
            <div className="mt-2 pr-2">
               <p className="text-gray-400 font-minimal text-sm leading-relaxed tracking-wide">
                 {data.description}
               </p>
            </div>
          ) : null}
        </div>

        {/* Action Footer */}
        <div className="relative z-10 flex items-center justify-between mt-8 pt-4 border-t border-white/5" style={{ transform: 'translateZ(15px)' }}>
          <span 
            className={`
              text-[10px] font-bold font-mono tracking-widest uppercase transition-all duration-300
              ${isClicked ? 'text-white' : 'text-gray-500 group-hover:text-gray-300'}
            `}
          >
            {isClicked ? 'INITIALIZING...' : 'SECURE CONNECTION'}
          </span>
          
          <div className={`
            flex items-center justify-center w-8 h-8 rounded-full
            bg-white/5 text-gray-400
            transition-all duration-300
            group-hover:bg-white/10 group-hover:text-white group-hover:scale-110
            ${isClicked ? `scale-90 ${styles.indicator} text-black` : ''}
          `}>
             <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="transition-transform group-hover:rotate-[-45deg]">
               <path d="M5 12h14"></path>
               <path d="M12 5l7 7-7 7"></path>
             </svg>
          </div>
        </div>
      </Component>
    </div>
  );
};
