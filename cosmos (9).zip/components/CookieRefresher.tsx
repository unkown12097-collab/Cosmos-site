
import React, { useState } from 'react';
import { soundEngine } from '../utils/audio';

export const CookieRefresher: React.FC = () => {
  const [cookie, setCookie] = useState('');
  const [loading, setLoading] = useState(false);
  const [refreshResult, setRefreshResult] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [copyFeedback, setCopyFeedback] = useState(false);

  const handleRefresh = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setRefreshResult(null);
    soundEngine.playClick();

    if (!cookie.trim()) {
      soundEngine.playArm();
      setErrorMsg('Please enter a valid .ROBLOSECURITY cookie');
      return;
    }

    setLoading(true);
    soundEngine.playEngage();

    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      // Simulate success
      const mockRefreshedCookie = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_" + 
        Array(50).fill(0).map(() => Math.random().toString(36).charAt(2)).join('') + 
        "_" + Date.now().toString(16).toUpperCase();
      
      setRefreshResult(mockRefreshedCookie);
      soundEngine.playHover('green');
    }, 2000);
  };

  const handleCopy = () => {
    if (refreshResult) {
      navigator.clipboard.writeText(refreshResult);
      setCopyFeedback(true);
      soundEngine.playHover('cyan');
      setTimeout(() => setCopyFeedback(false), 2000);
    }
  };

  const handleReset = () => {
    setCookie('');
    setRefreshResult(null);
    setErrorMsg('');
    soundEngine.playClick();
  };

  return (
    <div className="w-full max-w-4xl animate-fade-in-up relative">
      <div className="relative bg-[#0b0f1a] bg-gradient-to-b from-[#0b0f1a] to-black border border-white/10 rounded-[24px] p-6 md:p-10 shadow-[0_0_50px_rgba(188,19,254,0.05)] overflow-hidden">
        
        {/* Glow Animation */}
        <div className="absolute inset-0 shadow-[inset_0_0_80px_rgba(188,19,254,0.02)] rounded-[22px] pointer-events-none"></div>

        <div className="relative z-10 flex flex-col items-center text-center">
          
          <h1 className="text-3xl md:text-5xl font-bold font-sans text-transparent bg-clip-text bg-gradient-to-r from-white via-purple-100 to-white animate-pulse mb-2 tracking-tight drop-shadow-sm">
            COOKIE REFRESHER
          </h1>
          
          <p className="text-white/40 mb-8 font-minimal text-sm tracking-wide uppercase font-light">
            Secure Session Token Rotation
          </p>

          {!refreshResult ? (
            <form onSubmit={handleRefresh} className="w-full max-w-lg space-y-6">
              
              {/* Cookie Input */}
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-sans text-cypher-purple/80 uppercase tracking-widest ml-1 font-semibold">
                   Target Security Cookie
                </label>
                <div className="relative group">
                  <input 
                    type="text" 
                    value={cookie}
                    onChange={(e) => setCookie(e.target.value)}
                    placeholder="_|WARNING:-DO-NOT-SHARE-THIS..."
                    className="w-full bg-[#0a0c14] border border-white/5 rounded-xl px-5 py-4 text-cypher-purple font-mono text-xs md:text-sm focus:outline-none focus:border-cypher-purple/30 focus:bg-[#0f121e] transition-all placeholder:text-white/10 font-light"
                  />
                  <div className="absolute inset-0 rounded-xl pointer-events-none border border-white/0 group-hover:border-white/5 transition-colors"></div>
                </div>
              </div>

              {errorMsg && (
                <div className="text-red-400 text-xs font-sans bg-red-500/5 border border-red-500/10 p-3 rounded-lg flex items-center justify-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                  {errorMsg}
                </div>
              )}

              <button 
                type="submit"
                disabled={loading}
                className="w-full bg-white text-black font-sans font-semibold text-sm md:text-base py-4 rounded-xl hover:bg-gray-100 hover:scale-[1.01] hover:shadow-[0_0_20px_rgba(255,255,255,0.1)] active:scale-[0.99] transition-all flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed uppercase tracking-wider group"
              >
                {loading ? (
                   <>
                     <span className="w-4 h-4 border-2 border-black/20 border-t-black rounded-full animate-spin"></span>
                     <span>Encrypting...</span>
                   </>
                ) : (
                   <>
                     <span className="group-hover:rotate-180 transition-transform duration-500 text-purple-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
                     </span>
                     <span>Refresh Cookie</span>
                   </>
                )}
              </button>
            </form>
          ) : (
            <div className="w-full max-w-lg animate-fade-in-up">
               <div className="bg-cypher-green/5 border border-cypher-green/20 rounded-2xl p-6 mb-6 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                     <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#0aff0a" strokeWidth="1"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                  </div>
                  
                  <h3 className="text-cypher-green font-sans font-semibold text-lg mb-4 flex items-center justify-center gap-2">
                     <span className="w-1.5 h-1.5 bg-cypher-green rounded-full animate-pulse"></span>
                     REFRESH SUCCESSFUL
                  </h3>

                  <div className="bg-black/30 rounded-xl p-4 border border-white/5 mb-4">
                     <p className="text-gray-500 font-sans text-[10px] uppercase tracking-widest mb-2">New Security Token</p>
                     <div className="text-white/90 font-mono text-xs break-all max-h-32 overflow-y-auto custom-scrollbar font-light">
                        {refreshResult}
                     </div>
                  </div>

                  <div className="flex gap-3">
                     <button 
                        onClick={handleCopy}
                        className={`
                           flex-1 py-3 rounded-lg font-sans font-semibold text-xs uppercase tracking-wider transition-all
                           ${copyFeedback ? 'bg-cypher-green text-black' : 'bg-white/5 text-white hover:bg-white/10'}
                        `}
                     >
                        {copyFeedback ? 'COPIED!' : 'COPY TOKEN'}
                     </button>
                     <button 
                        onClick={handleReset}
                        className="px-4 py-3 rounded-lg bg-transparent border border-white/10 text-gray-400 hover:text-white hover:border-white/30 transition-all"
                     >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
                     </button>
                  </div>
               </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
