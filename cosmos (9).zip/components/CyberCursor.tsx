
import React, { useEffect, useState, useRef } from 'react';

export const CyberCursor: React.FC = () => {
  const [position, setPosition] = useState({ x: -100, y: -100 });
  const [trail, setTrail] = useState<{ x: number; y: number; id: number }[]>([]);
  const [clicks, setClicks] = useState<{ x: number; y: number; id: number }[]>([]);
  const counter = useRef(0);

  useEffect(() => {
    const updatePosition = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      
      // Add point to trail periodically
      counter.current += 1;
      if (counter.current % 3 === 0) { // Throttle trail creation
        setTrail(prev => [
          ...prev.slice(-15), // Keep last 15 points
          { x: e.clientX, y: e.clientY, id: Date.now() + Math.random() }
        ]);
      }
    };

    const handleClick = (e: MouseEvent) => {
      setClicks(prev => [...prev, { x: e.clientX, y: e.clientY, id: Date.now() }]);
      // Clean up click after animation
      setTimeout(() => {
        setClicks(prev => prev.slice(1));
      }, 600);
    };

    window.addEventListener('mousemove', updatePosition);
    window.addEventListener('mousedown', handleClick);
    
    return () => {
      window.removeEventListener('mousemove', updatePosition);
      window.removeEventListener('mousedown', handleClick);
    };
  }, []);

  return (
    <>
      {/* Click Ripples */}
      {clicks.map((click) => (
        <div 
          key={click.id}
          className="fixed rounded-full border-cypher-cyan pointer-events-none z-[9998] animate-cursor-ripple"
          style={{
            left: click.x,
            top: click.y,
            transform: 'translate(-50%, -50%)',
            borderColor: 'rgba(0, 240, 255, 0.8)'
          }}
        />
      ))}

      {/* Ghost Trail */}
      {trail.map((point, index) => (
        <div
          key={point.id}
          className="fixed w-1.5 h-1.5 bg-cypher-cyan rounded-full pointer-events-none z-[9998]"
          style={{
            left: point.x,
            top: point.y,
            opacity: index / trail.length * 0.4, // Fade out tail
            transform: 'translate(-50%, -50%) scale(' + (index / trail.length) + ')',
            transition: 'opacity 0.2s'
          }}
        />
      ))}

      {/* Main Cursor */}
      <div
        className="fixed pointer-events-none z-[9999] mix-blend-difference"
        style={{
          left: position.x,
          top: position.y,
          transform: 'translate(-50%, -50%)'
        }}
      >
        {/* Crosshair */}
        <div className="relative w-8 h-8 flex items-center justify-center">
          <div className="absolute w-[1px] h-full bg-cypher-cyan/80"></div>
          <div className="absolute h-[1px] w-full bg-cypher-cyan/80"></div>
          <div className="absolute w-2 h-2 border border-cypher-magenta rotate-45"></div>
        </div>
      </div>
    </>
  );
};
