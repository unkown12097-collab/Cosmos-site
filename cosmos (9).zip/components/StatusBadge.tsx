import React, { useMemo } from 'react';
import { ThemeColor } from '../types';

interface StatusBadgeProps {
  status: string;
  theme: ThemeColor;
}

const textColors: Record<string, string> = {
  purple: 'text-cypher-purple',
  red: 'text-cypher-magenta',
  orange: 'text-orange-400',
  cyan: 'text-cypher-cyan',
  blue: 'text-cypher-cyan',
  magenta: 'text-cypher-magenta',
  green: 'text-cypher-green',
};

const bgColors: Record<string, string> = {
    purple: 'bg-cypher-purple',
    red: 'bg-cypher-magenta',
    orange: 'bg-orange-400',
    cyan: 'bg-cypher-cyan',
    blue: 'bg-cypher-cyan',
    magenta: 'bg-cypher-magenta',
    green: 'bg-cypher-green',
};

const shadowColors: Record<string, string> = {
  purple: 'rgba(188,19,254,0.5)',
  cyan: 'rgba(0,240,255,0.5)',
  green: 'rgba(10,255,10,0.5)',
  magenta: 'rgba(255,0,60,0.5)',
  red: 'rgba(255,0,60,0.5)',
  orange: 'rgba(255,165,0,0.5)',
  blue: 'rgba(59,130,246,0.5)',
};

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, theme }) => {
  const textColor = textColors[theme] || 'text-gray-400';
  const bgColor = bgColors[theme] || 'bg-gray-400';
  const shadowColor = shadowColors[theme] || 'rgba(255,255,255,0.2)';

  // Generate a random delay so multiple badges don't pulse in sync, creating an intermittent feel
  const delay = useMemo(() => Math.random() * 4, []);

  return (
    <div 
      className={`
        relative overflow-hidden
        flex items-center gap-2 px-2 py-0.5 
        border-l border-white/10 bg-black/20 
        animate-status-attention
        transition-all duration-300
        group-hover:border-white/60
        group-hover:shadow-[0_0_15px_-3px_var(--hover-shadow)]
        group-hover:bg-white/5
      `} 
      role="status" 
      aria-label={`System status: ${status}`}
      style={{ 
        borderLeftColor: 'currentColor',
        '--hover-shadow': shadowColor,
        animationDelay: `-${delay}s`
      } as React.CSSProperties}
    >
      <div className="relative flex items-center justify-center w-1.5 h-1.5">
         <span className={`absolute h-full w-full rounded-full ${bgColor} animate-ping-slow opacity-75`} style={{ animationDuration: '2s' }}></span>
         <span className={`relative h-1.5 w-1.5 ${bgColor} rounded-full`}></span>
      </div>
      
      <span className={`text-[9px] font-mono font-bold tracking-wider ${textColor} group-hover:brightness-125 transition-all duration-300`}>
        {status}
      </span>
    </div>
  );
};
