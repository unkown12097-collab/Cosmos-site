
import React, { useEffect, useRef } from 'react';

export const RedSnow: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;

    const setSize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };
    setSize();

    // Configuration
    const particleCount = 50; // Reduced count for a cleaner look
    const particles: { x: number; y: number; r: number; d: number; color: string; speed: number }[] = [];

    // Theme colors: Cyan, Purple, and White to match the dashboard
    const themeColors = [
      '0, 240, 255', // Cyan
      '188, 19, 254', // Purple
      '255, 255, 255' // White
    ];

    // Initialize particles
    for (let i = 0; i < particleCount; i++) {
      const colorBase = themeColors[Math.floor(Math.random() * themeColors.length)];
      const opacity = Math.random() * 0.3 + 0.1; // Subtle opacity for depth

      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        r: Math.random() * 1.5 + 0.5, // Radius between 0.5 and 2.0
        d: Math.random() * particleCount, // Density/Sway offset
        color: `rgba(${colorBase}, ${opacity})`,
        speed: Math.random() * 0.4 + 0.1 // Much slower speed for floating effect
      });
    }

    let animationFrameId: number;
    let angle = 0;

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      
      angle += 0.005; // Slower sway angle increment
      
      for (let i = 0; i < particleCount; i++) {
        const p = particles[i];
        
        ctx.beginPath();
        ctx.fillStyle = p.color;
        ctx.moveTo(p.x, p.y);
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2, true);
        ctx.fill();

        // Update coordinates
        p.y += p.speed;
        // Gentler horizontal sway
        p.x += Math.sin(angle + p.d) * 0.3;

        // Wrap around screen
        if (p.y > height) {
          p.y = -10;
          p.x = Math.random() * width;
        }
        if (p.x > width + 5) {
          p.x = -5;
        } else if (p.x < -5) {
          p.x = width + 5;
        }
      }
      
      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    window.addEventListener('resize', setSize);

    return () => {
      window.removeEventListener('resize', setSize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 pointer-events-none z-[1]" 
      style={{ mixBlendMode: 'screen' }}
      aria-hidden="true"
    />
  );
};
