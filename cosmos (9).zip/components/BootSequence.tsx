
import React, { useState, useEffect, useRef } from 'react';
import { soundEngine } from '../utils/audio';

interface BootSequenceProps {
  onOpen: () => void;
  onComplete: () => void;
  step: 'booting' | 'revealing';
}

const bootLogs = [
  "INITIALIZING KERNEL...",
  "LOADING_VIRTUAL_DOM...",
  "BYPASSING_SECURITY_PROTOCOLS...",
  "ESTABLISHING_SECURE_UPLINK...",
  "DECRYPTING_ASSETS...",
  "OPTIMIZING_RENDER_PIPELINE...",
  "SYSTEM_READY."
];

const AsciiLogo = () => (
  <pre className="text-[0.5rem] md:text-[0.6rem] leading-[0.6rem] text-cypher-cyan font-mono mb-6 opacity-80 select-none hidden md:block">
{`
   ______  ____  _____ __  __  ____  _____
  / ____/ / __ \\/ ___//  \\/  |/ __ \\/ ___/
 / /     / / / /\\__ \\/ /\\/\\ / / / / \\__ \\ 
/ /___  / /_/ /___/ / /  / / /_/ / ___/ / 
\\____/  \\____//____/_/  /_/\\____/ /____/  
`}
  </pre>
);

export const BootSequence: React.FC<BootSequenceProps> = ({ onOpen, onComplete, step }) => {
  // Initialize state based on the 'step' prop.
  const [logs, setLogs] = useState<string[]>(step === 'revealing' ? bootLogs : []);
  const [progress, setProgress] = useState(step === 'revealing' ? 100 : 0);
  const [isOpening, setIsOpening] = useState(step === 'revealing');
  const [flash, setFlash] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // If we mount in (or switch to) 'revealing' state, bypass the loading animation
    if (step === 'revealing') {
      if (!isOpening) setIsOpening(true);
      if (progress < 100) setProgress(100);
      if (logs.length === 0) setLogs(bootLogs);
      return; 
    }

    let logIndex = 0;
    
    // Log interval
    const logInterval = setInterval(() => {
      if (logIndex < bootLogs.length) {
        setLogs(prev => [...prev, bootLogs[logIndex]]);
        soundEngine.playTick();
        logIndex++;
      } else {
        clearInterval(logInterval);
      }
    }, 400);

    // Progress bar interval
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          
          // Sequence: Flash -> Open Shutters -> Reveal App
          setTimeout(() => {
            setFlash(true); // Trigger white flash
            soundEngine.playHover('cyan'); 
            
            setTimeout(() => {
              setIsOpening(true); // Start shutter animation
              onOpen(); // Tell parent to render the main app underneath
              
              // Wait for shutter animation (1s) + buffer before unmounting
              setTimeout(onComplete, 1200); 
            }, 300);
          }, 500);
          
          return 100;
        }
        // Non-linear progress for realism
        const diff = 100 - prev;
        const jump = Math.random() * (diff / 10) + 0.5;
        return Math.min(prev + jump, 100);
      });
    }, 100);

    return () => {
      clearInterval(logInterval);
      clearInterval(progressInterval);
    };
  }, [step]); 

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  return (
    // STRICT TRANSPARENCY: No bg-black here.
    <div className="fixed inset-0 z-[9999] flex flex-col pointer-events-none select-none bg-transparent">
      {/* Top Shutter */}
      <div 
        className={`
          relative w-full bg-[#050505] border-b border-cypher-cyan/30 flex items-end justify-center overflow-hidden
          transition-transform duration-[1000ms] cubic-bezier(0.8, 0, 0.2, 1)
          ${isOpening ? '-translate-y-full' : 'translate-y-0'}
        `}
        style={{ height: '50vh', zIndex: 20 }}
      >
         <div className="absolute inset-0 opacity-10" 
              style={{ backgroundImage: 'radial-gradient(circle at 50% 100%, #00f0ff 1px, transparent 1px)', backgroundSize: '30px 30px' }}>
         </div>
         <div className="absolute bottom-6 right-8 flex flex-col items-end gap-1">
            <div className="flex gap-1">
              {[1,2,3].map(i => <div key={i} className="w-1 h-1 bg-cypher-cyan/50 animate-pulse"></div>)}
            </div>
            <div className="text-[10px] text-cypher-cyan/70 font-mono tracking-[0.3em]">SECURE_BOOT_SEQ</div>
         </div>
      </div>

      {/* Bottom Shutter */}
      <div 
        className={`
          relative w-full bg-[#050505] border-t border-cypher-cyan/30 flex items-start justify-center overflow-hidden
          transition-transform duration-[1000ms] cubic-bezier(0.8, 0, 0.2, 1)
          ${isOpening ? 'translate-y-full' : 'translate-y-0'}
        `}
        style={{ height: '50vh', zIndex: 20 }}
      >
         <div className="absolute inset-0 opacity-10" 
              style={{ backgroundImage: 'radial-gradient(circle at 50% 0%, #00f0ff 1px, transparent 1px)', backgroundSize: '30px 30px' }}>
         </div>
         <div className="absolute top-6 left-8 flex flex-col gap-1">
            <div className="text-[10px] text-cypher-cyan/70 font-mono tracking-[0.3em]">INIT_PROTOCOL_V4</div>
            <div className="h-px w-24 bg-gradient-to-r from-cypher-cyan/50 to-transparent"></div>
         </div>
      </div>

      {/* Flash Effect */}
      <div 
        className={`
          absolute inset-0 bg-white z-30 pointer-events-none mix-blend-overlay
          transition-opacity duration-500 ease-out
          ${flash ? 'opacity-0' : 'opacity-0'} 
        `}
        style={{ opacity: flash && !isOpening ? 0.8 : 0 }}
      ></div>

      {/* Center Content */}
      <div className={`absolute inset-0 flex items-center justify-center z-40 transition-all duration-700 ${isOpening ? 'opacity-0 scale-125 filter blur-md' : 'opacity-100 scale-100'}`}>
        <div className="w-full max-w-lg mx-4 bg-black/80 backdrop-blur-md border border-cypher-cyan/20 p-1 relative overflow-hidden shadow-[0_0_100px_-20px_rgba(0,240,255,0.2)]">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cypher-cyan/20 to-transparent -translate-x-full animate-[shimmer_2s_infinite]"></div>
            <div className="relative bg-black/90 p-6 md:p-8 flex flex-col items-center">
                <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cypher-cyan"></div>
                <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cypher-cyan"></div>
                <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cypher-cyan"></div>
                <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cypher-cyan"></div>

                <AsciiLogo />

                <div className="relative w-32 h-32 mb-8 flex items-center justify-center">
                    <div className="absolute inset-0 border-2 border-cypher-cyan/10 rounded-full"></div>
                    <div className="absolute inset-0 border-t-2 border-cypher-cyan rounded-full animate-spin"></div>
                    <div className="absolute inset-2 border-2 border-cypher-cyan/10 rounded-full"></div>
                    <div className="absolute inset-2 border-r-2 border-cypher-purple rounded-full animate-spin-reverse" style={{ animationDuration: '3s' }}></div>
                    <div className="absolute inset-0 flex items-center justify-center animate-pulse">
                        <span className="text-2xl font-bold font-mono text-white">{Math.floor(progress)}%</span>
                    </div>
                </div>

                <div className="w-full h-24 overflow-hidden relative font-mono text-xs md:text-sm border-t border-white/5 pt-4">
                  <div className="absolute top-0 left-0 right-0 h-4 bg-gradient-to-b from-black/90 to-transparent z-10"></div>
                  <div className="absolute bottom-0 left-0 right-0 h-4 bg-gradient-to-t from-black/90 to-transparent z-10"></div>
                  <div className="flex flex-col justify-end h-full pb-1">
                    {logs.slice(-4).map((log, i) => (
                      <div key={i} className="flex items-center gap-2 text-cypher-cyan/80 animate-fade-in-up">
                        <span className="text-cypher-purple text-[10px]">>></span>
                        <span className="tracking-wide">{log}</span>
                      </div>
                    ))}
                    <div ref={logEndRef} />
                  </div>
                </div>

                <div className="w-full h-1 bg-white/10 mt-4 overflow-hidden relative">
                    <div 
                        className="h-full bg-cypher-cyan shadow-[0_0_15px_#00f0ff] transition-all duration-100 ease-out relative"
                        style={{ width: `${progress}%` }}
                    >
                         <div className="absolute right-0 top-0 bottom-0 w-2 bg-white/50 animate-pulse"></div>
                    </div>
                </div>
                
                <div className="flex justify-between w-full mt-2 text-[10px] text-gray-500 font-mono uppercase tracking-widest">
                    <span>Mem: {4096 + Math.floor(progress * 12)}MB</span>
                    <span>Encrypted</span>
                </div>
            </div>
        </div>
      </div>
      
      {/* Scanlines and Vignette - fade out when opening */}
      <div className={`absolute inset-0 pointer-events-none bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPgo8cmVjdCB3aWR0aD0iNCIgaGVpZ2h0PSI0IiBmaWxsPSIjMDAwIiBmaWxsLW9wYWNpdHk9IjAuMiIvPgo8L3N2Zz4=')] opacity-50 z-50 transition-opacity duration-1000 ${isOpening ? 'opacity-0' : 'opacity-50'}`}></div>
      <div className={`absolute inset-0 pointer-events-none bg-vignette z-40 transition-opacity duration-1000 ${isOpening ? 'opacity-0' : 'opacity-100'}`}></div>
    </div>
  );
};
