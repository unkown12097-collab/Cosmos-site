
import React, { useState } from 'react';
import { TextScramble } from './TextScramble';
import { soundEngine } from '../utils/audio';

interface IntroSequenceProps {
  onComplete: () => void;
}

export const IntroSequence: React.FC<IntroSequenceProps> = ({ onComplete }) => {
  const [clicked, setClicked] = useState(false);
  const [exiting, setExiting] = useState(false);

  const handleEnter = () => {
    if (clicked) return;
    setClicked(true);
    soundEngine.playEngage();
    
    // Start exit animation immediately
    setExiting(true);
    
    // Complete after animation
    setTimeout(() => {
      onComplete();
    }, 1000);
  };

  return (
    <div 
      onClick={handleEnter}
      className={`
        fixed inset-0 z-[10000] bg-[#020202] flex flex-col items-center justify-center select-none cursor-pointer
        transition-opacity duration-1000 ease-in-out
        ${exiting ? 'opacity-0 pointer-events-none' : 'opacity-100'}
      `}
    >
      <div className="relative z-10 text-center px-4 group">
        
        {/* Main Title */}
        <div className="h-24 flex flex-col items-center justify-center overflow-hidden gap-4">
            <h1 className="text-4xl md:text-6xl font-light text-white tracking-[0.2em] font-sans drop-shadow-[0_0_15px_rgba(255,255,255,0.1)] group-hover:scale-105 transition-transform duration-700">
                <TextScramble text="COSMOS" autoStart={true} />
            </h1>
            
            <div className={`
              text-sm font-mono text-cypher-cyan/70 tracking-[0.5em] uppercase transition-all duration-500
              ${clicked ? 'opacity-0 translate-y-4' : 'opacity-100 animate-pulse'}
            `}>
              [ Click to Enter ]
            </div>
        </div>

      </div>

      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-cypher-purple/5 via-black to-black opacity-40"></div>
      
      {/* Subtle Grid */}
      <div className="absolute inset-0 opacity-[0.03]" 
           style={{ backgroundImage: 'linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.1) 1px, transparent 1px)', backgroundSize: '40px 40px' }}>
      </div>
    </div>
  );
};
