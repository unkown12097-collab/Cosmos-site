
import React, { useState } from 'react';
import { soundEngine } from '../utils/audio';

type LinkType = 'profile' | 'private-server' | 'group';
type ShortenerService = 'isgd' | 'tinyurl' | 'bitly' | 'rebrandly' | 'none';

export const HyperlinkGenerator: React.FC = () => {
  const [linkType, setLinkType] = useState<LinkType>('profile');
  const [url, setUrl] = useState('');
  const [shortener, setShortener] = useState<ShortenerService>('isgd');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [copyFeedback, setCopyFeedback] = useState(false);

  const handleTypeChange = (type: LinkType) => {
    setLinkType(type);
    soundEngine.playClick();
  };

  const generateRandomString = (length: number) => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  const shortenUrl = async (longUrl: string, service: ShortenerService): Promise<string> => {
    let formattedUrl = longUrl;
    if (!formattedUrl.startsWith('http://') && !formattedUrl.startsWith('https://')) {
      formattedUrl = 'https://' + formattedUrl;
    }

    if (service === 'none') return formattedUrl;

    try {
      if (service === 'isgd') {
        const response = await fetch(`https://is.gd/create.php?format=json&url=${encodeURIComponent(formattedUrl)}`);
        if (!response.ok) throw new Error('is.gd API Error');
        const data = await response.json();
        return data.shorturl || formattedUrl;
      } 
      
      if (service === 'tinyurl') {
        const response = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(formattedUrl)}`);
        if (!response.ok) throw new Error('TinyURL API Error');
        return await response.text();
      }

      // Demo modes for auth-required services
      if (service === 'bitly') return `https://bit.ly/${generateRandomString(7)}`;
      if (service === 'rebrandly') return `https://rebrand.ly/${generateRandomString(8)}`;

      return formattedUrl;
    } catch (error) {
      console.error('Shortening failed:', error);
      return formattedUrl; // Fallback to original
    }
  };

  const handleGenerate = async () => {
    if (!url.trim()) return;

    setLoading(true);
    soundEngine.playEngage();
    
    try {
      const shortUrl = await shortenUrl(url, shortener);
      let formattedLink = '';

      // Logic based on original tool
      switch (linkType) {
        case 'profile':
          formattedLink = `[https_:_//www.roblox.com/users/6700452/profile](${shortUrl})`;
          break;
        case 'private-server':
          formattedLink = `[https_:_//www.roblox.com/share?code=9b3bf13e5fe0894d941ac87ac52f8d1d&type=Server](${shortUrl})`;
          break;
        case 'group':
          formattedLink = `[https_:_//www.roblox.com/groups/7429401045](${shortUrl})`;
          break;
      }

      setResult(formattedLink);
      soundEngine.playHover('green');
    } catch (e) {
      setResult('Error generating link. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopyFeedback(true);
    soundEngine.playHover('cyan');
    setTimeout(() => setCopyFeedback(false), 2000);
  };

  return (
    <div className="w-full max-w-4xl animate-fade-in-up">
      <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 md:p-8 overflow-hidden">
        {/* Decor */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-cypher-cyan/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 rounded-xl bg-cypher-magenta/10 border border-cypher-magenta/30 flex items-center justify-center text-cypher-magenta">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white font-sans tracking-tight">LINK GENERATOR</h2>
            <p className="text-xs font-mono text-gray-500 tracking-widest uppercase">Encryption Level: Standard</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Controls Column */}
          <div className="space-y-6">
            
            {/* Type Selector */}
            <div className="space-y-2">
              <label className="text-xs font-mono text-cypher-cyan uppercase tracking-wider">Target Type</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'profile', icon: '👤', label: 'Profile' },
                  { id: 'private-server', icon: '🔒', label: 'Server' },
                  { id: 'group', icon: '👥', label: 'Group' }
                ].map((type) => (
                  <button
                    key={type.id}
                    onClick={() => handleTypeChange(type.id as LinkType)}
                    className={`
                      flex flex-col items-center justify-center p-3 rounded-xl border transition-all duration-300
                      ${linkType === type.id 
                        ? 'bg-cypher-cyan/10 border-cypher-cyan text-cypher-cyan shadow-[0_0_15px_-5px_rgba(0,240,255,0.3)]' 
                        : 'bg-white/5 border-white/5 text-gray-400 hover:bg-white/10 hover:border-white/20'}
                    `}
                  >
                    <span className="text-lg mb-1">{type.icon}</span>
                    <span className="text-[10px] font-mono font-bold uppercase">{type.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* URL Input */}
            <div className="space-y-2">
              <label className="text-xs font-mono text-cypher-cyan uppercase tracking-wider">Target URL</label>
              <div className="relative group">
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://roblox.com/..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cypher-cyan/50 focus:bg-white/10 transition-all font-mono placeholder:text-gray-600"
                />
                <div className="absolute inset-0 rounded-xl pointer-events-none border border-cypher-cyan/0 group-focus-within:border-cypher-cyan/30 transition-all duration-500"></div>
              </div>
            </div>

            {/* Service Selector */}
            <div className="space-y-2">
               <label className="text-xs font-mono text-cypher-cyan uppercase tracking-wider">Anonymizer Service</label>
               <div className="relative">
                 <select
                    value={shortener}
                    onChange={(e) => setShortener(e.target.value as ShortenerService)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cypher-cyan/50 appearance-none font-mono cursor-pointer"
                 >
                    <option value="isgd">is.gd (Recommended)</option>
                    <option value="tinyurl">TinyURL</option>
                    <option value="bitly">Bit.ly (Demo)</option>
                    <option value="rebrandly">Rebrand.ly (Demo)</option>
                    <option value="none">No Shortening</option>
                 </select>
                 <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                    ▼
                 </div>
               </div>
            </div>

            {/* Action Button */}
            <button
              onClick={handleGenerate}
              disabled={loading || !url}
              className={`
                w-full py-4 rounded-xl font-bold font-sans tracking-wider uppercase transition-all duration-300 relative overflow-hidden group
                ${loading || !url 
                  ? 'bg-white/5 text-gray-500 cursor-not-allowed border border-white/5' 
                  : 'bg-cypher-cyan/10 text-cypher-cyan border border-cypher-cyan/50 hover:bg-cypher-cyan/20 hover:shadow-[0_0_20px_rgba(0,240,255,0.3)]'}
              `}
            >
               {loading ? (
                 <span className="animate-pulse">Processing...</span>
               ) : (
                 <>
                   <span className="relative z-10 flex items-center justify-center gap-2">
                     <span className="text-lg">⚡</span> Generate Link
                   </span>
                   <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                 </>
               )}
            </button>

          </div>

          {/* Results Column */}
          <div className="relative bg-black/40 rounded-xl border border-white/5 p-1 flex flex-col">
            <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
            
            {/* Terminal Header */}
            <div className="flex items-center justify-between px-4 py-2 border-b border-white/5 bg-white/5">
                <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500/20 border border-red-500/50"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/20 border border-yellow-500/50"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500/20 border border-green-500/50"></div>
                </div>
                <div className="text-[10px] font-mono text-gray-500">OUTPUT_TERMINAL</div>
            </div>

            {/* Content */}
            <div className="flex-1 p-4 flex flex-col min-h-[250px]">
               {result ? (
                 <div className="flex flex-col h-full animate-fade-in">
                    <label className="text-[10px] font-mono text-gray-500 mb-2">GENERATED PAYLOAD:</label>
                    <textarea 
                      readOnly
                      value={result}
                      className="flex-1 w-full bg-transparent resize-none text-cypher-green font-mono text-sm focus:outline-none mb-4 custom-scrollbar"
                    />
                    
                    <button
                      onClick={handleCopy}
                      className={`
                        w-full py-2 rounded-lg text-xs font-mono font-bold uppercase transition-all duration-200
                        ${copyFeedback 
                          ? 'bg-cypher-green text-black border border-cypher-green' 
                          : 'bg-white/5 text-gray-300 border border-white/10 hover:bg-white/10 hover:text-white'}
                      `}
                    >
                      {copyFeedback ? 'COPIED TO CLIPBOARD' : 'COPY TO CLIPBOARD'}
                    </button>
                 </div>
               ) : (
                 <div className="flex-1 flex flex-col items-center justify-center text-gray-600 space-y-3 opacity-50">
                    <div className="w-12 h-12 rounded-full border border-dashed border-gray-600 animate-spin-slow"></div>
                    <span className="text-xs font-mono tracking-wider">AWAITING INPUT...</span>
                 </div>
               )}
            </div>

            {/* Terminal Footer */}
            <div className="px-4 py-2 border-t border-white/5 bg-black/20 flex justify-between items-center text-[9px] font-mono text-gray-600">
               <span>STATUS: {loading ? 'PROCESSING' : 'IDLE'}</span>
               <span>MEM: {loading ? 'ALLOCATING' : 'READY'}</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
