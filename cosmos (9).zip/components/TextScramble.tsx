
import React, { useState, useEffect, useRef } from 'react';
import { soundEngine } from '../utils/audio';

interface TextScrambleProps {
  text: string;
  className?: string;
  autoStart?: boolean;
}

const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&[]<>';

export const TextScramble: React.FC<TextScrambleProps> = ({ text, className = '', autoStart = true }) => {
  const [displayText, setDisplayText] = useState('');

  useEffect(() => {
    if (!autoStart) return;

    let iteration = 0;
    const speed = 30; // ms per frame

    const interval = setInterval(() => {
      const currentText = text
        .split('')
        .map((letter, index) => {
          if (index < iteration) {
            return text[index];
          }
          return chars[Math.floor(Math.random() * chars.length)];
        })
        .join('');

      setDisplayText(currentText);

      // Play a tiny tick sound if we're still scrambling
      if (iteration < text.length) {
        soundEngine.playTick();
      }

      if (iteration >= text.length) {
        clearInterval(interval);
      }

      iteration += 1 / 3;
    }, speed);

    return () => clearInterval(interval);
  }, [text, autoStart]);

  return <span className={className}>{displayText}</span>;
};
